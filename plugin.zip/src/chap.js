function execute(url) {
    let host = "http://192.168.1.150:18423";
    try {
        if (CONFIG_URL) {
            host = CONFIG_URL;
        }
    } catch(e) {}

    let match = url.match(/reader\/(\d+)\/(\d+)/);
    if (!match) {
        return Response.error("Đường dẫn chương không hợp lệ.");
    }
    let bookId = match[1];
    let chapId = match[2];

    // 1. Fetch book preview — server trả về txt_file path chính xác (Fix #2)
    let previewResponse = fetch(host + "/api/preview/" + bookId, { headers: { "ngrok-skip-browser-warning": "true" } });
    if (!previewResponse.ok) {
        return Response.error("Không thể kết nối đến máy chủ Tomato Downloader hoặc không tìm thấy thông tin truyện.");
    }
    let preview = previewResponse.json();
    let bookName = preview.book_name;
    let txtFilePath = preview.txt_file; // URL path do server scan trực tiếp

    // 2. Fetch the TOC from Fanqie official API to map chapter IDs to titles
    let tocUrl = "https://fanqienovel.com/api/reader/directory/detail?bookId=" + bookId;
    let tocResponse = fetch(tocUrl);
    let chapters = [];
    if (tocResponse.ok) {
        let tocJson = tocResponse.json();
        let volumes = tocJson.data.chapterListWithVolume;
        for (let i = 0; i < volumes.length; i++) {
            let vol = volumes[i];
            for (let j = 0; j < vol.length; j++) {
                chapters.push({
                    id: vol[j].itemId,
                    title: vol[j].title
                });
            }
        }
    }

    // Find current and next chapter titles
    let currentTitle = "";
    let nextTitle = "";
    for (let i = 0; i < chapters.length; i++) {
        if (chapters[i].id == chapId) {
            currentTitle = chapters[i].title;
            if (i + 1 < chapters.length) {
                nextTitle = chapters[i + 1].title;
            }
            break;
        }
    }

    // 3. Đọc từ file .txt — dùng txtFilePath từ server thay vì tự đoán (Fix #2)
    if (txtFilePath && currentTitle) {
        let cacheKey = "tomato_txt_" + bookId;
        let txtContent = null;
        try {
            txtContent = localStorage.getItem(cacheKey);
        } catch(e) {}

        if (!txtContent) {
            let txtUrl = host + txtFilePath;
            let txtResponse = fetch(txtUrl, { headers: { "ngrok-skip-browser-warning": "true" } });
            if (txtResponse.ok) {
                txtContent = txtResponse.text();
                clearOldTxtCaches(bookId);
                try {
                    localStorage.setItem(cacheKey, txtContent);
                } catch(e) {}
            }
        }

        if (txtContent && currentTitle) {
            let chapterText = extractChapterFromTxt(txtContent, currentTitle, nextTitle);
            if (chapterText) {
                return Response.success(formatContent(chapterText));
            }
        }
    }

    // 4. Fallback: Try reading from status.json (Custom Build / Source Build support)
    let jsonCacheKey = "tomato_cache_" + bookId;
    let data = null;
    try {
        let cachedData = localStorage.getItem(jsonCacheKey);
        if (cachedData) data = JSON.parse(cachedData);
    } catch(e) {}

    let pair = null;
    if (data && data.downloaded) {
        pair = data.downloaded[chapId];
    }

    // If chapter not found in cache, fetch fresh status.json from server
    if (!pair || !pair[1]) {
        let response = fetch(host + "/download/" + bookId + "/status.json", { headers: { "ngrok-skip-browser-warning": "true" } });
        if (response.ok) {
            data = response.json();

            // Kiểm tra xem status.json có thật sự có dữ liệu không
            // Nếu rỗng hoàn toàn (dummy {}) → coi như chưa tải → trigger download
            let hasRealData = data && data.book_name;
            if (!hasRealData) {
                // Xóa cache sai (dummy) để lần sau fetch lại
                try { localStorage.removeItem(jsonCacheKey); } catch(e) {}
                // Trigger download giống như khi 404
                let triggerResponse = fetch(host + "/api/jobs", {
                    method: "POST",
                    headers: {
                        "Content-Type": "application/json",
                        "ngrok-skip-browser-warning": "true"
                    },
                    body: JSON.stringify({ "book_id": bookId })
                });
                if (triggerResponse.ok) {
                    return Response.error("Truyện này chưa được tải về máy tính. Máy chủ đã tự động kích hoạt tải xuống.\n\nVui lòng đợi 1-2 phút rồi ấn 'Tải lại chương'!");
                }
            }

            try {
                localStorage.setItem(jsonCacheKey, JSON.stringify(data));
            } catch(e) {
                clearOldCaches();
                try {
                    localStorage.setItem(jsonCacheKey, JSON.stringify(data));
                } catch(err) {}
            }
            if (data && data.downloaded) {
                pair = data.downloaded[chapId];
            }
        } else if (response.status === 404) {
            // Trigger automatic download job
            let triggerResponse = fetch(host + "/api/jobs", {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                    "ngrok-skip-browser-warning": "true"
                },
                body: JSON.stringify({ "book_id": bookId })
            });
            if (triggerResponse.ok) {
                return Response.error("Truyện này chưa được tải về máy tính. Máy chủ đã tự động kích hoạt tải xuống.\n\nVui lòng đợi 1-2 phút rồi ấn 'Tải lại chương'!");
            }
        }
    }

    if (pair && pair[1]) {
        return Response.success(formatContent(pair[1]));
    }

    // Chưa có nội dung → gọi /api/progress để hiện tiến độ thực tế
    let progressMsg = "Chưa có nội dung cho chương này.\nVui lòng kiểm tra tiến độ tải trên máy tính.";
    try {
        let progressRes = fetch(host + "/api/progress/" + bookId, { headers: { "ngrok-skip-browser-warning": "true" } });
        if (progressRes.ok) {
            let prog = progressRes.json();
            if (prog.done) {
                progressMsg = "✅ Đã tải xong! Hãy ấn 'Tải lại chương' để đọc.";
            } else if (prog.downloaded > 0 && prog.total > 0) {
                progressMsg = "⏳ Đang tải về máy tính...\n\n"
                    + "📥 Đã tải: " + prog.downloaded + " / " + prog.total + " chương (" + prog.percent + "%)\n\n"
                    + "Ấn 'Tải lại chương' sau khi hoàn tất.";
            } else if (prog.downloaded > 0) {
                progressMsg = "⏳ Đang tải về máy tính...\n\n"
                    + "📥 Đã tải: " + prog.downloaded + " chương\n\n"
                    + "Ấn 'Tải lại chương' sau khi hoàn tất.";
            }
        }
    } catch(e) {}

    return Response.error(progressMsg);
}

/**
 * Fix #3: Tìm nội dung chương chính xác hơn bằng boundary matching.
 * Tìm dòng khớp chính xác với title thay vì indexOf thuần.
 */
function extractChapterFromTxt(txt, currentTitle, nextTitle) {
    // Tách thành các dòng để tìm boundary chính xác
    let lines = txt.split(/\r?\n/);
    let startLine = -1;
    let endLine = lines.length;

    // Tìm dòng là tiêu đề chương hiện tại (khớp chính xác sau khi trim)
    for (let i = 0; i < lines.length; i++) {
        let trimmed = lines[i].trim();
        if (trimmed === currentTitle || trimmed.toLowerCase() === currentTitle.toLowerCase()) {
            startLine = i + 1; // nội dung bắt đầu từ dòng kế tiếp
            break;
        }
    }

    // Nếu không khớp chính xác, fallback về indexOf
    if (startLine === -1) {
        let idx = txt.indexOf(currentTitle);
        if (idx === -1) {
            let txtLower = txt.toLowerCase();
            idx = txtLower.indexOf(currentTitle.toLowerCase());
        }
        if (idx === -1) return null;

        let startIdx = idx + currentTitle.length;
        let endIdx = txt.length;
        if (nextTitle) {
            let nextIdx = txt.indexOf(nextTitle);
            if (nextIdx === -1) nextIdx = txt.toLowerCase().indexOf(nextTitle.toLowerCase());
            if (nextIdx !== -1 && nextIdx > startIdx) endIdx = nextIdx;
        }
        return txt.substring(startIdx, endIdx).trim();
    }

    // Tìm dòng là tiêu đề chương kế tiếp
    if (nextTitle) {
        for (let i = startLine; i < lines.length; i++) {
            let trimmed = lines[i].trim();
            if (trimmed === nextTitle || trimmed.toLowerCase() === nextTitle.toLowerCase()) {
                endLine = i;
                break;
            }
        }
    }

    return lines.slice(startLine, endLine).join("\n").trim();
}

function formatContent(content) {
    return content
        .replace(/&lt;br&gt;/g, "<br>")
        .replace(/&lt;p&gt;/g, "")
        .replace(/&lt;\/p&gt;/g, "<br>")
        .replace(/\r\n|\r|\n/g, "<br><br>");
}

function clearOldTxtCaches(currentBookId) {
    try {
        let keysToRemove = [];
        for (let i = 0; i < localStorage.length; i++) {
            let key = localStorage.key(i);
            if (key && key.indexOf("tomato_txt_") === 0 && key !== "tomato_txt_" + currentBookId) {
                keysToRemove.push(key);
            }
        }
        keysToRemove.forEach(k => localStorage.removeItem(k));
    } catch(e) {}
}

function clearOldCaches() {
    try {
        let keysToRemove = [];
        for (let i = 0; i < localStorage.length; i++) {
            let key = localStorage.key(i);
            if (key && key.indexOf("tomato_cache_") === 0) {
                keysToRemove.push(key);
            }
        }
        keysToRemove.forEach(k => localStorage.removeItem(k));
    } catch(e) {}
}
