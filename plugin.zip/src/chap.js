function execute(url) {
    let host = "http://192.168.1.150:18423";
    try {
        if (CONFIG_URL) { host = CONFIG_URL; }
    } catch(e) {}

    // Parse bookId và chapId từ URL dạng /reader/{bookId}/{chapId}
    let match = url.match(/reader\/(\d+)\/(\d+)/);
    if (!match) {
        return Response.error("Đường dẫn chương không hợp lệ.");
    }
    let bookId = match[1];
    let chapId = match[2];

    // === BƯỚC 1: Lấy danh sách chương (TOC) từ server PC ===
    // Server tự fetch Fanqie và cache lại — điện thoại không cần gọi Fanqie trực tiếp.
    // Client cũng cache TOC vào localStorage trong 5 phút để tránh gọi server lặp lại.
    let currentTitle = "";
    let nextTitle = "";
    let tocCacheKey = "tomato_toc_" + bookId;
    let chapters = null;

    try {
        let cached = localStorage.getItem(tocCacheKey);
        if (cached) {
            let parsed = JSON.parse(cached);
            // Dùng cache phía client nếu còn hiệu lực (5 phút)
            if (parsed.ts && (Date.now() - parsed.ts) < 300000) {
                chapters = parsed.data;
            }
        }
    } catch(e) {}

    if (!chapters) {
        let tocResponse = fetch(host + "/api/toc/" + bookId, {
            headers: { "ngrok-skip-browser-warning": "true" }
        });
        if (!tocResponse.ok) {
            return Response.error("Không thể lấy mục lục từ máy chủ PC. Vui lòng kiểm tra kết nối.");
        }
        let tocData = tocResponse.json();
        chapters = tocData.chapters;
        // Lưu cache phía client
        try {
            localStorage.setItem(tocCacheKey, JSON.stringify({ data: chapters, ts: Date.now() }));
        } catch(e) {}
    }

    // Tìm tiêu đề chương hiện tại và chương kế tiếp trong danh sách
    for (let i = 0; i < chapters.length; i++) {
        if (chapters[i].id == chapId) {
            currentTitle = chapters[i].title;
            if (i + 1 < chapters.length) {
                nextTitle = chapters[i + 1].title;
            }
            break;
        }
    }

    if (!currentTitle) {
        return Response.error("Không tìm thấy thông tin chương ID=" + chapId + " trong mục lục.");
    }

    // === BƯỚC 2: Lấy nội dung chương từ server PC ===
    // Server tự đọc file .txt và trả về đúng nội dung 1 chương — không tải cả file về nữa.
    let chapUrl = host + "/api/chapter/" + bookId + "/" + chapId
        + "?title=" + encodeURIComponent(currentTitle)
        + (nextTitle ? "&next_title=" + encodeURIComponent(nextTitle) : "");

    let chapResponse = fetch(chapUrl, {
        headers: { "ngrok-skip-browser-warning": "true" }
    });

    if (chapResponse.ok) {
        let chapData = chapResponse.json();
        if (chapData.content) {
            return Response.success(formatContent(chapData.content));
        }
        return Response.error("Máy chủ không tìm thấy nội dung chương trong file. Vui lòng thử lại.");
    }

    // === BƯỚC 3: Xử lý lỗi từ server ===

    // 404 = file .txt chưa có trên PC → kích hoạt tải xuống
    if (chapResponse.status === 404) {
        let triggerResponse = fetch(host + "/api/jobs", {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
                "ngrok-skip-browser-warning": "true"
            },
            body: JSON.stringify({ "book_id": bookId })
        });
        if (triggerResponse.ok) {
            return Response.error(
                "Truyện này chưa được tải về máy tính. Máy chủ đã tự động kích hoạt tải xuống.\n\n" +
                "Vui lòng đợi 1-2 phút rồi ấn 'Tải lại chương'!"
            );
        }
    }

    // 422 = file có trên PC nhưng không tìm thấy tiêu đề chương trong file .txt
    // KHÔNG trigger /api/jobs — không cần tải lại, đây là vấn đề định dạng tiêu đề
    if (chapResponse.status === 422) {
        return Response.error(
            "Không tìm thấy nội dung chương \"" + currentTitle + "\" trong file truyện.\n\n" +
            "Tiêu đề trong file .txt không khớp với dữ liệu từ Fanqie."
        );
    }

    return Response.error("Chưa có nội dung cho chương này. Vui lòng kiểm tra tiến độ tải trên máy tính.");
}


function formatContent(content) {
    return content
        .replace(/&lt;br&gt;/g, "<br>")
        .replace(/&lt;p&gt;/g, "")
        .replace(/&lt;\/p&gt;/g, "<br>")
        .replace(/\r\n|\r|\n/g, "<br><br>");
}
