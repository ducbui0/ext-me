function execute(url) {
    let bookId = url.match(/page\/(\d+)/)[1];

    // Cache TOC vào localStorage với TTL 1 giờ để tránh gọi API Fanqie mỗi lần mở mục lục
    let cacheKey = "tomato_toc_" + bookId;
    let list = null;
    try {
        let raw = localStorage.getItem(cacheKey);
        if (raw) {
            let parsed = JSON.parse(raw);
            if (Date.now() - parsed.ts < 60 * 60 * 1000) { // TTL 1 giờ
                list = parsed.data;
            }
        }
    } catch(e) {}

    if (!list) {
        let newurl = "https://fanqienovel.com/api/reader/directory/detail?bookId=" + bookId;
        let response = fetch(newurl);
        if (!response.ok) {
            return Response.error("Không thể lấy mục lục từ trang Fanqie. Vui lòng thử lại sau.");
        }
        let doc = response.json();
        let el = doc.data.chapterListWithVolume;
        list = [];

        for (let i = 0; i < el.length; i++) {
            let volume = el[i];
            for (let j = 0; j < volume.length; j++) {
                let chap = volume[j];
                list.push({
                    name: chap.title,
                    url: "https://fanqienovel.com/reader/" + bookId + "/" + chap.itemId
                });
            }
        }

        // Lưu vào localStorage cùng timestamp
        try {
            localStorage.setItem(cacheKey, JSON.stringify({ data: list, ts: Date.now() }));
        } catch(e) {}
    }

    return Response.success(list);
}
