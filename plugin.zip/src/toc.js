function execute(url) {
    let host = "http://192.168.1.150:18423";
    try {
        if (CONFIG_URL) { host = CONFIG_URL; }
    } catch(e) {}

    let bookId = url.match(/page\/(\d+)/)[1];
    let newurl = host + "/api/toc/" + bookId;
    
    let response = fetch(newurl, {
        headers: { "ngrok-skip-browser-warning": "true" }
    });
    
    if (response.ok) {
        let doc = response.json();
        let chapters = doc.chapters;
        let list = [];
        
        for (let i = 0; i < chapters.length; i++) {
            list.push({
                name: chapters[i].title,
                url: "https://fanqienovel.com/reader/" + bookId + "/" + chapters[i].id
            });
        }
        return Response.success(list);
    }
    return Response.error("Không thể lấy mục lục từ máy chủ PC. Vui lòng thử lại sau.");
}
